import { Transaction, User, CurrencyRate } from '../types/types';

export const generateCardNumber = (): string => {
  const prefix = '4532'; // Visa prefix
  let cardNumber = prefix;
  
  for (let i = 0; i < 12; i++) {
    cardNumber += Math.floor(Math.random() * 10);
  }
  
  return cardNumber.replace(/(.{4})/g, '$1 ').trim();
};

export const generatePIN = (): string => {
  return Math.floor(1000 + Math.random() * 9000).toString();
};

export const formatCurrency = (amount: number, currency: string = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
  }).format(amount);
};

export const formatDate = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const createTransaction = (
  type: Transaction['type'],
  amount: number,
  description: string,
  balance: number
): Transaction => {
  return {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    type,
    amount,
    timestamp: new Date(),
    description,
    balance,
  };
};

export const validatePIN = (pin: string): boolean => {
  return /^\d{4}$/.test(pin);
};

export const checkDailyLimit = (transactions: Transaction[], amount: number): boolean => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const todayWithdrawals = transactions.filter(
    t => t.type === 'withdrawal' && t.timestamp >= today
  );
  
  const totalWithdrawn = todayWithdrawals.reduce((sum, t) => sum + t.amount, 0);
  const DAILY_LIMIT = 1000;
  
  return totalWithdrawn + amount <= DAILY_LIMIT;
};

export const currencyRates: CurrencyRate[] = [
  { code: 'USD', name: 'US Dollar', rate: 1, symbol: '$' },
  { code: 'EUR', name: 'Euro', rate: 0.85, symbol: '€' },
  { code: 'GBP', name: 'British Pound', rate: 0.73, symbol: '£' },
  { code: 'JPY', name: 'Japanese Yen', rate: 110, symbol: '¥' },
  { code: 'CAD', name: 'Canadian Dollar', rate: 1.25, symbol: 'C$' },
  { code: 'AUD', name: 'Australian Dollar', rate: 1.35, symbol: 'A$' },
];

export const convertCurrency = (amount: number, fromRate: number, toRate: number): number => {
  return (amount / fromRate) * toRate;
};

export const generateReceipt = (user: User, transactions: Transaction[]): string => {
  const receipt = `
========================================
           ATM SIMULATION RECEIPT
========================================

Card Number: **** **** **** ${user.cardNumber.slice(-4)}
Date: ${formatDate(new Date())}

========================================
           TRANSACTION HISTORY
========================================

${transactions.slice(-10).map(t => 
  `${formatDate(t.timestamp)}
${t.description.toUpperCase()}
Amount: ${formatCurrency(t.amount)}
Balance: ${formatCurrency(t.balance)}
----------------------------------------`
).join('\n')}

========================================
           CURRENT ACCOUNT STATUS
========================================

Checking Balance: ${formatCurrency(user.balance)}
Savings Balance: ${formatCurrency(user.savingsBalance)}
Savings Goal: ${formatCurrency(user.savingsGoal)}

========================================
Thank you for using ATM Simulation!
This is a simulated transaction receipt.
========================================
  `;
  
  return receipt.trim();
};

export const downloadReceipt = (content: string): void => {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `ATM_Receipt_${new Date().toISOString().split('T')[0]}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
};