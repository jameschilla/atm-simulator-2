import React from 'react';
import { 
  CreditCard, 
  Download, 
  TrendingUp, 
  Plus, 
  Minus, 
  Target, 
  Globe, 
  FileText, 
  LogOut,
  Eye
} from 'lucide-react';
import { ATMScreen } from '../types/types';

interface ATMSideButtonsProps {
  onButtonPress: (action: string) => void;
  currentScreen: ATMScreen;
}

export const ATMSideButtons: React.FC<ATMSideButtonsProps> = ({ onButtonPress, currentScreen }) => {
  const leftButtons = [
    { action: 'balance', label: 'Balance', icon: Eye, color: 'blue' },
    { action: 'withdraw', label: 'Withdraw', icon: Minus, color: 'red' },
    { action: 'deposit', label: 'Deposit', icon: Plus, color: 'green' },
    { action: 'savings_goal', label: 'Savings', icon: Target, color: 'purple' },
  ];

  const rightButtons = [
    { action: 'currency_conversion', label: 'Currency', icon: Globe, color: 'orange' },
    { action: 'transaction_history', label: 'History', icon: FileText, color: 'indigo' },
    { action: 'download_receipt', label: 'Receipt', icon: Download, color: 'teal' },
    { action: 'exit', label: 'Exit', icon: LogOut, color: 'gray' },
  ];

  const getButtonStyle = (color: string, isActive: boolean = false) => {
    const colors = {
      blue: 'from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 border-blue-400',
      red: 'from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 border-red-400',
      green: 'from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 border-green-400',
      purple: 'from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 border-purple-400',
      orange: 'from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 border-orange-400',
      indigo: 'from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 border-indigo-400',
      teal: 'from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 border-teal-400',
      gray: 'from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 border-gray-400',
    };

    const baseStyle = "w-full p-3 rounded-xl font-semibold text-white transition-all duration-200 transform hover:scale-105 shadow-lg border-2 active:scale-95 flex items-center justify-center space-x-2";
    const gradientStyle = `bg-gradient-to-b ${colors[color as keyof typeof colors]}`;
    
    return `${baseStyle} ${gradientStyle} ${isActive ? 'ring-2 ring-white ring-offset-2 ring-offset-gray-800' : ''}`;
  };

  const isButtonActive = (action: string) => {
    const screenActionMap: { [key in ATMScreen]?: string } = {
      balance: 'balance',
      withdraw: 'withdraw',
      deposit: 'deposit',
      savings_goal: 'savings_goal',
      currency_conversion: 'currency_conversion',
      transaction_history: 'transaction_history',
    };

    return screenActionMap[currentScreen] === action;
  };

  const ButtonComponent = ({ button, side }: { button: any, side: 'left' | 'right' }) => {
    const Icon = button.icon;
    const isActive = isButtonActive(button.action);
    
    return (
      <button
        onClick={() => onButtonPress(button.action)}
        className={getButtonStyle(button.color, isActive)}
        disabled={currentScreen === 'welcome' || currentScreen === 'pin_entry'}
      >
        <Icon className="w-4 h-4" />
        <span className="text-sm">{button.label}</span>
      </button>
    );
  };

  return (
    <div className="bg-gradient-to-b from-gray-700 to-gray-900 rounded-2xl p-4 border border-gray-600">
      <div className="text-center text-gray-300 text-sm mb-4 font-semibold">ACTION BUTTONS</div>
      
      <div className="flex justify-between space-x-4">
        {/* Left Side Buttons */}
        <div className="flex-1 space-y-3">
          {leftButtons.map((button) => (
            <ButtonComponent key={button.action} button={button} side="left" />
          ))}
        </div>

        {/* Right Side Buttons */}
        <div className="flex-1 space-y-3">
          {rightButtons.map((button) => (
            <ButtonComponent key={button.action} button={button} side="right" />
          ))}
        </div>
      </div>

      {(currentScreen === 'welcome' || currentScreen === 'pin_entry') && (
        <div className="mt-4 text-center">
          <p className="text-yellow-400 text-xs">
            ⚠️ Complete PIN entry to access features
          </p>
        </div>
      )}
    </div>
  );
};