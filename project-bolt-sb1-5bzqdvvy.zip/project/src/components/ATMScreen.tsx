import React from 'react';
import { User, Transaction, ATMScreen as ATMScreenType } from '../types/types';
import { formatCurrency, formatDate, currencyRates, convertCurrency } from '../utils/atmUtils';
import { CreditCard, Shield, Clock, TrendingUp, Globe, Receipt, LogOut } from 'lucide-react';

interface ATMScreenProps {
  screen: ATMScreenType;
  user: User;
  transactions: Transaction[];
  pinInput: string;
  currentInput: string;
  selectedCurrency: string;
  lastTransaction: Transaction | null;
  errorMessage: string;
  onStartATM: () => void;
}

export const ATMScreen: React.FC<ATMScreenProps> = ({
  screen,
  user,
  transactions,
  pinInput,
  currentInput,
  selectedCurrency,
  lastTransaction,
  errorMessage,
  onStartATM,
}) => {
  const renderScreen = () => {
    switch (screen) {
      case 'welcome':
        return (
          <div className="text-center space-y-6 py-8">
            <CreditCard className="w-16 h-16 text-blue-400 mx-auto" />
            <h2 className="text-3xl font-bold text-white">Welcome to ATM</h2>
            <p className="text-gray-300 text-lg">Insert your card to begin</p>
            <button
              onClick={onStartATM}
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-3 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all transform hover:scale-105"
            >
              Start Transaction
            </button>
          </div>
        );

      case 'pin_entry':
        return (
          <div className="text-center space-y-6 py-8">
            <Shield className="w-16 h-16 text-green-400 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Enter Your PIN</h2>
            <div className="flex justify-center space-x-2">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full border-2 ${
                    i < pinInput.length ? 'bg-green-400 border-green-400' : 'border-gray-400'
                  }`}
                />
              ))}
            </div>
            {errorMessage && (
              <div className="text-red-400 text-sm bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                {errorMessage}
              </div>
            )}
            <p className="text-gray-400 text-sm">Use the keypad to enter your 4-digit PIN</p>
          </div>
        );

      case 'main_menu':
        return (
          <div className="space-y-6 py-4">
            <h2 className="text-2xl font-bold text-white text-center">Main Menu</h2>
            <div className="text-center">
              <p className="text-gray-300">Card: **** **** **** {user.cardNumber.slice(-4)}</p>
              <p className="text-green-400 font-semibold">Available Balance: {formatCurrency(user.balance)}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-900/20 rounded-lg border border-blue-500/30">
                <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <p className="text-white text-sm">Balance Inquiry</p>
                <p className="text-gray-400 text-xs">Check your balance</p>
              </div>
              <div className="text-center p-3 bg-green-900/20 rounded-lg border border-green-500/30">
                <Receipt className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <p className="text-white text-sm">Transaction History</p>
                <p className="text-gray-400 text-xs">View recent activity</p>
              </div>
              <div className="text-center p-3 bg-purple-900/20 rounded-lg border border-purple-500/30">
                <Globe className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                <p className="text-white text-sm">Currency Exchange</p>
                <p className="text-gray-400 text-xs">Convert currencies</p>
              </div>
              <div className="text-center p-3 bg-orange-900/20 rounded-lg border border-orange-500/30">
                <TrendingUp className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                <p className="text-white text-sm">Savings Goal</p>
                <p className="text-gray-400 text-xs">Set savings target</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm text-center">Select an option using the side buttons</p>
          </div>
        );

      case 'balance':
        return (
          <div className="text-center space-y-6 py-8">
            <TrendingUp className="w-16 h-16 text-blue-400 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Account Balance</h2>
            <div className="space-y-4">
              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <p className="text-gray-300 text-sm">Checking Account</p>
                <p className="text-white text-3xl font-bold">{formatCurrency(user.balance)}</p>
              </div>
              <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
                <p className="text-gray-300 text-sm">Savings Account</p>
                <p className="text-white text-2xl font-bold">{formatCurrency(user.savingsBalance)}</p>
              </div>
              {user.savingsGoal > 0 && (
                <div className="bg-purple-900/20 p-2 rounded-lg border border-purple-500/30">
                  <p className="text-gray-300 text-xs">Savings Goal Progress</p>
                  <div className="w-full bg-gray-700 rounded-full h-2 mt-1">
                    <div 
                      className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((user.savingsBalance / user.savingsGoal) * 100, 100)}%` }}
                    />
                  </div>
                  <p className="text-purple-400 text-xs mt-1">
                    {formatCurrency(user.savingsBalance)} / {formatCurrency(user.savingsGoal)}
                  </p>
                </div>
              )}
            </div>
          </div>
        );

      case 'withdraw':
        return (
          <div className="space-y-6 py-4">
            <h2 className="text-2xl font-bold text-white text-center">Cash Withdrawal</h2>
            <div className="text-center">
              <p className="text-gray-300">Available Balance: {formatCurrency(user.balance)}</p>
              <p className="text-blue-400 text-sm">Daily limit: $1,000</p>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg">
              <p className="text-gray-300 text-sm mb-2">Enter amount to withdraw:</p>
              <p className="text-white text-2xl font-bold">${currentInput || '0.00'}</p>
            </div>
            {errorMessage && (
              <div className="text-red-400 text-sm bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                {errorMessage}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="text-center p-2 bg-blue-900/20 rounded border border-blue-500/30">
                <p className="text-blue-400">Quick: $20</p>
              </div>
              <div className="text-center p-2 bg-blue-900/20 rounded border border-blue-500/30">
                <p className="text-blue-400">Quick: $40</p>
              </div>
              <div className="text-center p-2 bg-blue-900/20 rounded border border-blue-500/30">
                <p className="text-blue-400">Quick: $100</p>
              </div>
              <div className="text-center p-2 bg-blue-900/20 rounded border border-blue-500/30">
                <p className="text-blue-400">Quick: $200</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm text-center">Enter amount and press ENTER</p>
          </div>
        );

      case 'deposit':
        return (
          <div className="space-y-6 py-4">
            <h2 className="text-2xl font-bold text-white text-center">Cash Deposit</h2>
            <div className="text-center">
              <p className="text-gray-300">Current Balance: {formatCurrency(user.balance)}</p>
            </div>
            <div className="bg-gray-800 p-4 rounded-lg">
              <p className="text-gray-300 text-sm mb-2">Enter amount to deposit:</p>
              <p className="text-white text-2xl font-bold">${currentInput || '0.00'}</p>
            </div>
            {errorMessage && (
              <div className="text-red-400 text-sm bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                {errorMessage}
              </div>
            )}
            <div className="bg-green-900/20 p-3 rounded-lg border border-green-500/30">
              <p className="text-green-400 text-sm">💡 Insert cash into the deposit slot</p>
              <p className="text-gray-400 text-xs">Enter the amount you're depositing</p>
            </div>
            <p className="text-gray-400 text-sm text-center">Enter amount and press ENTER</p>
          </div>
        );

      case 'savings_goal':
        return (
          <div className="space-y-6 py-4">
            <h2 className="text-2xl font-bold text-white text-center">Savings Goal</h2>
            <div className="text-center space-y-2">
              <p className="text-gray-300">Current Savings: {formatCurrency(user.savingsBalance)}</p>
              {user.savingsGoal > 0 && (
                <p className="text-blue-400">Current Goal: {formatCurrency(user.savingsGoal)}</p>
              )}
            </div>
            <div className="bg-gray-800 p-4 rounded-lg">
              <p className="text-gray-300 text-sm mb-2">Set new savings goal:</p>
              <p className="text-white text-2xl font-bold">${currentInput || '0.00'}</p>
            </div>
            {user.savingsGoal > 0 && (
              <div className="bg-purple-900/20 p-3 rounded-lg border border-purple-500/30">
                <p className="text-purple-400 text-sm">Progress</p>
                <div className="w-full bg-gray-700 rounded-full h-3 mt-2">
                  <div 
                    className="bg-purple-500 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min((user.savingsBalance / user.savingsGoal) * 100, 100)}%` }}
                  />
                </div>
                <p className="text-gray-400 text-xs mt-1">
                  {((user.savingsBalance / user.savingsGoal) * 100).toFixed(1)}% complete
                </p>
              </div>
            )}
            {errorMessage && (
              <div className="text-red-400 text-sm bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                {errorMessage}
              </div>
            )}
            <p className="text-gray-400 text-sm text-center">Enter goal amount and press ENTER</p>
          </div>
        );

      case 'currency_conversion':
        return (
          <div className="space-y-4 py-4">
            <h2 className="text-xl font-bold text-white text-center">Currency Conversion</h2>
            <div className="text-center">
              <p className="text-gray-300 text-sm">Convert from USD</p>
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {currencyRates.map((currency) => (
                <div key={currency.code} className="bg-gray-800 p-3 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="text-white font-semibold">{currency.name}</p>
                    <p className="text-gray-400 text-sm">{currency.code}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400">{currency.symbol}{convertCurrency(100, 1, currency.rate).toFixed(2)}</p>
                    <p className="text-gray-400 text-xs">per $100 USD</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-gray-400 text-xs text-center">Exchange rates are simulated</p>
          </div>
        );

      case 'transaction_history':
        return (
          <div className="space-y-4 py-4">
            <h2 className="text-xl font-bold text-white text-center">Transaction History</h2>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {transactions.slice(-10).reverse().map((transaction, index) => (
                <div key={transaction.id} className="bg-gray-800 p-3 rounded-lg">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-white font-semibold text-sm">{transaction.description}</p>
                    <p className={`font-bold ${
                      transaction.type === 'deposit' ? 'text-green-400' : 
                      transaction.type === 'withdrawal' ? 'text-red-400' : 'text-blue-400'
                    }`}>
                      {transaction.type === 'deposit' ? '+' : transaction.type === 'withdrawal' ? '-' : ''}
                      {transaction.amount > 0 ? formatCurrency(transaction.amount) : ''}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-gray-400 text-xs">{formatDate(transaction.timestamp)}</p>
                    <p className="text-gray-300 text-xs">Bal: {formatCurrency(transaction.balance)}</p>
                  </div>
                </div>
              ))}
            </div>
            {transactions.length === 0 && (
              <p className="text-gray-400 text-center">No transactions yet</p>
            )}
          </div>
        );

      case 'receipt':
        return (
          <div className="text-center space-y-6 py-8">
            <Receipt className="w-16 h-16 text-green-400 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Transaction Complete</h2>
            {lastTransaction && (
              <div className="bg-gray-800 p-4 rounded-lg border border-gray-600">
                <p className="text-gray-300 text-sm">{lastTransaction.description}</p>
                <p className="text-white text-xl font-bold">
                  {lastTransaction.type === 'deposit' ? '+' : lastTransaction.type === 'withdrawal' ? '-' : ''}
                  {lastTransaction.amount > 0 ? formatCurrency(lastTransaction.amount) : 'N/A'}
                </p>
                <p className="text-blue-400 text-sm">New Balance: {formatCurrency(lastTransaction.balance)}</p>
                <p className="text-gray-400 text-xs mt-2">{formatDate(lastTransaction.timestamp)}</p>
              </div>
            )}
            <p className="text-green-400">✓ Transaction Successful</p>
            <p className="text-gray-400 text-sm">Please take your cash and receipt</p>
          </div>
        );

      case 'exit':
        return (
          <div className="text-center space-y-6 py-8">
            <LogOut className="w-16 h-16 text-orange-400 mx-auto" />
            <h2 className="text-2xl font-bold text-white">Thank You</h2>
            <p className="text-gray-300">Please take your card</p>
            <p className="text-orange-400">Have a great day!</p>
            <div className="animate-pulse">
              <Clock className="w-8 h-8 text-blue-400 mx-auto" />
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-8">
            <p className="text-white">Screen not found</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-[400px] bg-gradient-to-b from-blue-900 to-blue-950 rounded-xl p-6 flex flex-col justify-center">
      <div className="bg-black rounded-lg p-6 min-h-[350px] flex flex-col justify-center">
        {renderScreen()}
      </div>
    </div>
  );
};