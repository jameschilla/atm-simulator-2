import React, { useState, useEffect } from 'react';
import { ATMScreen } from './ATMScreen';
import { ATMKeypad } from './ATMKeypad';
import { ATMSideButtons } from './ATMSideButtons';
import { User, Transaction, ATMScreen as ATMScreenType } from '../types/types';
import { createTransaction, validatePIN, checkDailyLimit, generateReceipt, downloadReceipt } from '../utils/atmUtils';

interface ATMInterfaceProps {
  user: User;
  onExit: () => void;
}

export const ATMInterface: React.FC<ATMInterfaceProps> = ({ user: initialUser, onExit }) => {
  const [currentScreen, setCurrentScreen] = useState<ATMScreenType>('welcome');
  const [user, setUser] = useState<User>(initialUser);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [pinInput, setPinInput] = useState('');
  const [currentInput, setCurrentInput] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [lastTransaction, setLastTransaction] = useState<Transaction | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [pinAttempts, setPinAttempts] = useState(0);

  // Initialize with some starting transactions
  useEffect(() => {
    const initialTransactions = [
      createTransaction('balance_inquiry', 0, 'Account opened', user.balance),
      createTransaction('deposit', 1000, 'Initial deposit', user.balance),
    ];
    setTransactions(initialTransactions);
  }, [user.balance]);

  const handleKeypadPress = (key: string) => {
    if (key === 'clear') {
      setCurrentInput('');
      setPinInput('');
      setErrorMessage('');
      return;
    }

    if (key === 'enter') {
      handleEnter();
      return;
    }

    if (key === 'cancel') {
      handleCancel();
      return;
    }

    // Handle numeric input
    if (currentScreen === 'pin_entry') {
      if (pinInput.length < 4) {
        setPinInput(prev => prev + key);
      }
    } else {
      setCurrentInput(prev => prev + key);
    }
  };

  const handleEnter = () => {
    switch (currentScreen) {
      case 'pin_entry':
        if (pinInput === user.pin) {
          setPinAttempts(0);
          setCurrentScreen('main_menu');
          setPinInput('');
          setErrorMessage('');
        } else {
          setPinAttempts(prev => prev + 1);
          setPinInput('');
          if (pinAttempts >= 2) {
            setErrorMessage('Too many incorrect attempts. Please try again later.');
            setTimeout(() => {
              setCurrentScreen('welcome');
              setPinAttempts(0);
              setErrorMessage('');
            }, 3000);
          } else {
            setErrorMessage(`Incorrect PIN. ${3 - pinAttempts - 1} attempts remaining.`);
          }
        }
        break;
        
      case 'withdraw':
        handleWithdraw(parseFloat(currentInput) || 0);
        break;
        
      case 'deposit':
        handleDeposit(parseFloat(currentInput) || 0);
        break;
        
      case 'savings_goal':
        handleSavingsGoal();
        break;
        
      default:
        break;
    }
  };

  const handleCancel = () => {
    setCurrentInput('');
    setPinInput('');
    setErrorMessage('');
    
    if (currentScreen === 'welcome' || currentScreen === 'pin_entry') {
      return;
    }
    
    if (currentScreen === 'main_menu') {
      setCurrentScreen('welcome');
    } else {
      setCurrentScreen('main_menu');
    }
  };

  const handleSideButtonPress = (action: string) => {
    setErrorMessage('');
    
    switch (action) {
      case 'balance':
        setCurrentScreen('balance');
        const balanceTransaction = createTransaction('balance_inquiry', 0, 'Balance inquiry', user.balance);
        setTransactions(prev => [...prev, balanceTransaction]);
        setLastTransaction(balanceTransaction);
        break;
        
      case 'withdraw':
        setCurrentScreen('withdraw');
        setCurrentInput('');
        break;
        
      case 'deposit':
        setCurrentScreen('deposit');
        setCurrentInput('');
        break;
        
      case 'savings_goal':
        setCurrentScreen('savings_goal');
        setCurrentInput('');
        break;
        
      case 'currency_conversion':
        setCurrentScreen('currency_conversion');
        setCurrentInput('');
        break;
        
      case 'transaction_history':
        setCurrentScreen('transaction_history');
        break;
        
      case 'download_receipt':
        handleReceiptDownload();
        break;
        
      case 'exit':
        setCurrentScreen('exit');
        setTimeout(onExit, 2000);
        break;
        
      default:
        break;
    }
  };

  const handleWithdraw = (amount: number) => {
    if (amount <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }
    
    if (amount > user.balance) {
      setErrorMessage('Insufficient funds');
      return;
    }
    
    if (!checkDailyLimit(transactions, amount)) {
      setErrorMessage('Daily withdrawal limit exceeded ($1,000)');
      return;
    }
    
    const newBalance = user.balance - amount;
    const transaction = createTransaction('withdrawal', amount, `Cash withdrawal`, newBalance);
    
    setUser(prev => ({ ...prev, balance: newBalance }));
    setTransactions(prev => [...prev, transaction]);
    setLastTransaction(transaction);
    setCurrentInput('');
    setCurrentScreen('receipt');
  };

  const handleDeposit = (amount: number) => {
    if (amount <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }
    
    const newBalance = user.balance + amount;
    const transaction = createTransaction('deposit', amount, `Cash deposit`, newBalance);
    
    setUser(prev => ({ ...prev, balance: newBalance }));
    setTransactions(prev => [...prev, transaction]);
    setLastTransaction(transaction);
    setCurrentInput('');
    setCurrentScreen('receipt');
  };

  const handleSavingsGoal = () => {
    const goalAmount = parseFloat(currentInput) || 0;
    if (goalAmount <= 0) {
      setErrorMessage('Please enter a valid savings goal');
      return;
    }
    
    setUser(prev => ({ ...prev, savingsGoal: goalAmount }));
    setCurrentInput('');
    setCurrentScreen('main_menu');
  };

  const handleReceiptDownload = () => {
    const receipt = generateReceipt(user, transactions);
    downloadReceipt(receipt);
  };

  const startATM = () => {
    setCurrentScreen('pin_entry');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-800 via-gray-900 to-black p-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-gradient-to-b from-gray-600 to-gray-800 rounded-3xl p-8 shadow-2xl border border-gray-500">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* ATM Screen */}
            <div className="lg:col-span-2">
              <div className="bg-gradient-to-b from-gray-900 to-black rounded-2xl p-6 border-4 border-gray-700 shadow-inner">
                <ATMScreen
                  screen={currentScreen}
                  user={user}
                  transactions={transactions}
                  pinInput={pinInput}
                  currentInput={currentInput}
                  selectedCurrency={selectedCurrency}
                  lastTransaction={lastTransaction}
                  errorMessage={errorMessage}
                  onStartATM={startATM}
                />
              </div>
            </div>

            {/* ATM Controls */}
            <div className="space-y-6">
              {/* Side Buttons */}
              <ATMSideButtons onButtonPress={handleSideButtonPress} currentScreen={currentScreen} />
              
              {/* Keypad */}
              <ATMKeypad onKeyPress={handleKeypadPress} />
              
              {/* Hardware Elements */}
              <div className="space-y-4">
                <div className="bg-gradient-to-b from-gray-700 to-gray-900 rounded-xl p-4 border border-gray-600">
                  <div className="text-center text-gray-300 text-sm mb-2">CARD SLOT</div>
                  <div className="h-3 bg-gradient-to-r from-gray-800 to-gray-900 rounded border border-gray-600"></div>
                </div>
                
                <div className="bg-gradient-to-b from-gray-700 to-gray-900 rounded-xl p-4 border border-gray-600">
                  <div className="text-center text-gray-300 text-sm mb-2">CASH DISPENSER</div>
                  <div className="h-8 bg-gradient-to-r from-gray-800 to-gray-900 rounded border border-gray-600 flex items-center justify-center">
                    <div className="text-gray-500 text-xs">💵</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* ATM Branding */}
          <div className="text-center mt-8 p-4 bg-gradient-to-r from-blue-900/20 to-purple-900/20 rounded-xl border border-gray-600">
            <h2 className="text-2xl font-bold text-white mb-2">ATM Simulation</h2>
            <p className="text-gray-300 text-sm">Educational Banking Technology Experience</p>
          </div>
        </div>
      </div>
    </div>
  );
};