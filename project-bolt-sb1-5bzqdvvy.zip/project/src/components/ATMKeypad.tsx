import React from 'react';

interface ATMKeypadProps {
  onKeyPress: (key: string) => void;
}

export const ATMKeypad: React.FC<ATMKeypadProps> = ({ onKeyPress }) => {
  const keys = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['clear', '0', 'enter'],
    ['cancel']
  ];

  const getKeyStyle = (key: string) => {
    const baseStyle = "p-4 rounded-xl font-bold transition-all duration-200 transform hover:scale-105 shadow-lg border-2 active:scale-95";
    
    switch (key) {
      case 'enter':
        return `${baseStyle} bg-gradient-to-b from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-green-400`;
      case 'clear':
        return `${baseStyle} bg-gradient-to-b from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white border-yellow-400`;
      case 'cancel':
        return `${baseStyle} bg-gradient-to-b from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white border-red-400 col-span-3`;
      default:
        return `${baseStyle} bg-gradient-to-b from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white border-gray-500`;
    }
  };

  const getKeyLabel = (key: string) => {
    switch (key) {
      case 'enter':
        return 'ENTER';
      case 'clear':
        return 'CLEAR';
      case 'cancel':
        return 'CANCEL';
      default:
        return key;
    }
  };

  return (
    <div className="bg-gradient-to-b from-gray-700 to-gray-900 rounded-2xl p-6 border border-gray-600">
      <div className="text-center text-gray-300 text-sm mb-4 font-semibold">KEYPAD</div>
      <div className="space-y-3">
        {keys.map((row, rowIndex) => (
          <div key={rowIndex} className={`grid ${row.length === 1 ? 'grid-cols-1' : 'grid-cols-3'} gap-3`}>
            {row.map((key) => (
              <button
                key={key}
                onClick={() => onKeyPress(key)}
                className={getKeyStyle(key)}
              >
                {getKeyLabel(key)}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};