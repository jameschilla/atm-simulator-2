import React, { useState } from 'react';
import { CreditCard, Shield, Clock, Globe, Smartphone, ArrowRight } from 'lucide-react';
import { SMSSimulation } from './SMSSimulation';

interface LoginPageProps {
  onLogin: (phoneNumber: string, cardNumber: string, pin: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [showSMS, setShowSMS] = useState(false);

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length >= 10) {
      setShowSMS(true);
    }
  };

  const handleSMSComplete = (cardNumber: string, pin: string) => {
    onLogin(phoneNumber, cardNumber, pin);
  };

  if (showSMS) {
    return <SMSSimulation phoneNumber={phoneNumber} onComplete={handleSMSComplete} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-4">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-2">ATM Simulation Platform</h1>
            <p className="text-blue-200 text-lg">Learn and Experience Banking Technology Safely</p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 mb-8 border border-white/20">
            <div className="flex justify-between items-center mb-6">
              <div className="flex space-x-2">
                <button
                  onClick={() => setCurrentPage(1)}
                  className={`px-4 py-2 rounded-lg transition-all ${
                    currentPage === 1 
                      ? 'bg-blue-500 text-white shadow-lg' 
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                >
                  Introduction
                </button>
                <button
                  onClick={() => setCurrentPage(2)}
                  className={`px-4 py-2 rounded-lg transition-all ${
                    currentPage === 2 
                      ? 'bg-blue-500 text-white shadow-lg' 
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                >
                  How to Use
                </button>
              </div>
              <div className="text-sm text-blue-200">
                Page {currentPage} of 2
              </div>
            </div>

            {currentPage === 1 && (
              <div className="space-y-6 text-white">
                <div>
                  <h2 className="text-2xl font-bold mb-4 text-blue-200">Welcome to ATM Simulation</h2>
                  <p className="text-lg leading-relaxed mb-4">
                    Our interactive ATM simulation provides a safe, educational environment where you can 
                    learn about Automated Teller Machine operations without any real financial risk. This 
                    platform is designed for educational purposes, helping users understand modern banking 
                    technology and ATM functionality.
                  </p>
                  <p className="text-lg leading-relaxed mb-6">
                    Whether you're a student learning about financial systems, a newcomer to digital banking, 
                    or someone who wants to practice ATM operations in a safe environment, this simulation 
                    offers realistic experiences with comprehensive features.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-blue-200">How ATM Technology Works</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                      <div className="flex items-center mb-3">
                        <Shield className="w-6 h-6 text-blue-400 mr-3" />
                        <h4 className="font-semibold">Security Systems</h4>
                      </div>
                      <p className="text-sm text-gray-300">
                        ATMs use encrypted communication, PIN verification, and secure card reading 
                        technology to protect your financial information during transactions.
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                      <div className="flex items-center mb-3">
                        <Globe className="w-6 h-6 text-green-400 mr-3" />
                        <h4 className="font-semibold">Network Connectivity</h4>
                      </div>
                      <p className="text-sm text-gray-300">
                        Real ATMs connect to banking networks in real-time to verify account 
                        information, check balances, and process transactions instantly.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-blue-200">Simulation Features</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-gradient-to-b from-blue-500/20 to-purple-500/20 rounded-xl border border-white/10">
                      <CreditCard className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                      <h4 className="font-semibold mb-1">Realistic Interface</h4>
                      <p className="text-sm text-gray-300">Authentic ATM design and layout</p>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-b from-green-500/20 to-blue-500/20 rounded-xl border border-white/10">
                      <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
                      <h4 className="font-semibold mb-1">Secure Learning</h4>
                      <p className="text-sm text-gray-300">Safe practice environment</p>
                    </div>
                    <div className="text-center p-4 bg-gradient-to-b from-purple-500/20 to-pink-500/20 rounded-xl border border-white/10">
                      <Clock className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                      <h4 className="font-semibold mb-1">Full Features</h4>
                      <p className="text-sm text-gray-300">Complete ATM functionality</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-blue-200">Educational Benefits</h3>
                  <ul className="space-y-2 text-gray-300">
                    <li className="flex items-start">
                      <ArrowRight className="w-5 h-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Learn ATM operations without financial risk or account requirements</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-5 h-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Understand banking concepts like daily limits, transaction history, and security</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-5 h-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Practice modern features like savings goals and currency conversion</span>
                    </li>
                    <li className="flex items-start">
                      <ArrowRight className="w-5 h-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Experience realistic transaction receipts and detailed history tracking</span>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {currentPage === 2 && (
              <div className="space-y-6 text-white">
                <div>
                  <h2 className="text-2xl font-bold mb-4 text-blue-200">Step-by-Step Guide</h2>
                  <p className="text-lg leading-relaxed mb-6">
                    Follow these simple steps to start your ATM simulation experience. This guide will 
                    walk you through the entire process, from initial setup to performing transactions.
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl p-6 border border-blue-500/20">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-4">1</div>
                      <h3 className="text-xl font-semibold text-blue-200">Phone Number Registration</h3>
                    </div>
                    <p className="text-gray-300 ml-12">
                      Enter your phone number in the form below. This simulates the account verification 
                      process used by real banking systems. Your number will be used to generate simulated 
                      SMS credentials.
                    </p>
                  </div>

                  <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-xl p-6 border border-green-500/20">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold mr-4">2</div>
                      <h3 className="text-xl font-semibold text-green-200">SMS Simulation</h3>
                    </div>
                    <p className="text-gray-300 ml-12">
                      You'll receive a simulated SMS message containing your virtual ATM card number and 
                      PIN. These credentials are randomly generated and only exist within this simulation 
                      for educational purposes.
                    </p>
                  </div>

                  <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl p-6 border border-purple-500/20">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold mr-4">3</div>
                      <h3 className="text-xl font-semibold text-purple-200">ATM Interface Access</h3>
                    </div>
                    <p className="text-gray-300 ml-12">
                      Enter the ATM interface where you'll see a realistic machine layout with a screen, 
                      keypad, card slot, and action buttons. Use your PIN to access the main menu.
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-blue-200">Available ATM Functions</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                      <h4 className="font-semibold text-blue-200 mb-2">Basic Operations</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Check Account Balance</li>
                        <li>• Cash Withdrawal (with daily limits)</li>
                        <li>• Cash Deposit</li>
                        <li>• Transaction History</li>
                      </ul>
                    </div>
                    <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                      <h4 className="font-semibold text-green-200 mb-2">Advanced Features</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Savings Goals Management</li>
                        <li>• Currency Conversion</li>
                        <li>• Receipt Download (.txt format)</li>
                        <li>• PIN Re-entry Security</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Smartphone className="w-6 h-6 text-amber-400 mr-3" />
                    <h4 className="font-semibold text-amber-200">Important Notes</h4>
                  </div>
                  <ul className="text-sm text-amber-100 space-y-1">
                    <li>• This is an educational simulation - no real money is involved</li>
                    <li>• All transactions and data are simulated and reset when you close  the browser</li>
                    <li>• Daily withdrawal limits are set to $1,000 for realistic experience</li>
                    <li>• Security features like PIN verification mirror real ATM systems</li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Start Your Simulation</h3>
            <form onSubmit={handlePhoneSubmit} className="max-w-md mx-auto">
              <div className="mb-6">
                <label htmlFor="phone" className="block text-white font-semibold mb-2">
                  Enter Your Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="(555) 123-4567"
                  className="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                  required
                  minLength={10}
                />
                <p className="text-blue-200 text-sm mt-2">
                  This will generate your simulated ATM card and PIN via SMS
                </p>
              </div>
              <button
                type="submit"
                disabled={phoneNumber.length < 10}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-3 px-6 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg"
              >
                Generate SMS Credentials
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};