import React, { useState, useEffect } from 'react';
import { Smartphone, MessageSquare, ArrowRight } from 'lucide-react';
import { generateCardNumber, generatePIN } from '../utils/atmUtils';

interface SMSSimulationProps {
  phoneNumber: string;
  onComplete: (cardNumber: string, pin: string) => void;
}

export const SMSSimulation: React.FC<SMSSimulationProps> = ({ phoneNumber, onComplete }) => {
  const [showSMS, setShowSMS] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [pin, setPin] = useState('');
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      const newCardNumber = generateCardNumber();
      const newPin = generatePIN();
      setCardNumber(newCardNumber);
      setPin(newPin);
      setShowSMS(true);
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleContinue = () => {
    onComplete(cardNumber, pin);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full mb-4">
            <Smartphone className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">SMS Verification</h1>
          <p className="text-blue-200">Generating your ATM credentials...</p>
        </div>

        {!showSMS ? (
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20 text-center">
            <div className="animate-spin w-12 h-12 border-4 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-white text-lg">Sending SMS to {phoneNumber}...</p>
            <p className="text-blue-200 text-sm mt-2">Please wait a moment</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-gray-900 rounded-3xl p-6 border border-gray-700 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <MessageSquare className="w-6 h-6 text-green-400 mr-2" />
                  <span className="text-white font-semibold">ATM Bank</span>
                </div>
                <span className="text-gray-400 text-sm">{currentTime}</span>
              </div>
              
              <div className="bg-blue-600 rounded-2xl p-4 text-white">
                <p className="font-semibold mb-3">🏧 ATM Simulation Credentials</p>
                <p className="text-sm mb-3">
                  Welcome to ATM Simulation! Here are your generated credentials:
                </p>
                
                <div className="bg-white/20 rounded-lg p-3 mb-3">
                  <p className="text-xs text-blue-100 mb-1">CARD NUMBER</p>
                  <p className="font-mono text-lg font-bold">{cardNumber}</p>
                </div>
                
                <div className="bg-white/20 rounded-lg p-3 mb-3">
                  <p className="text-xs text-blue-100 mb-1">PIN</p>
                  <p className="font-mono text-2xl font-bold tracking-widest">{pin}</p>
                </div>
                
                <p className="text-xs text-blue-100">
                  Keep these credentials safe. This is a simulation for educational purposes only.
                </p>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20">
              <div className="bg-amber-500/20 border border-amber-500/30 rounded-xl p-4 mb-4">
                <h3 className="text-amber-200 font-semibold mb-2">📝 Important Information</h3>
                <ul className="text-amber-100 text-sm space-y-1">
                  <li>• Your starting balance is $5,000.00</li>
                  <li>• Daily withdrawal limit is $1,000.00</li>
                  <li>• All transactions are simulated</li>
                  <li>• Data resets when you close the browser</li>
                </ul>
              </div>
              
              <button
                onClick={handleContinue}
                className="w-full bg-gradient-to-r from-green-500 to-blue-600 text-white font-bold py-3 px-6 rounded-xl hover:from-green-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center"
              >
                Continue to ATM
                <ArrowRight className="w-5 h-5 ml-2" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};