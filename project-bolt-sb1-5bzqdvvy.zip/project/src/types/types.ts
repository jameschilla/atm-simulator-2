export interface User {
  phoneNumber: string;
  cardNumber: string;
  pin: string;
  balance: number;
  savingsGoal: number;
  savingsBalance: number;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'balance_inquiry' | 'transfer_to_savings' | 'transfer_from_savings';
  amount: number;
  timestamp: Date;
  description: string;
  balance: number;
}

export type ATMScreen = 
  | 'welcome'
  | 'pin_entry'
  | 'main_menu'
  | 'balance'
  | 'withdraw'
  | 'deposit'
  | 'savings_goal'
  | 'currency_conversion'
  | 'transaction_history'
  | 'receipt'
  | 'exit';

export interface CurrencyRate {
  code: string;
  name: string;
  rate: number;
  symbol: string;
}