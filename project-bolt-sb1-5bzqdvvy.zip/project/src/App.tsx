import React, { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { ATMInterface } from './components/ATMInterface';
import { User } from './types/types';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (phoneNumber: string, cardNumber: string, pin: string) => {
    const newUser: User = {
      phoneNumber,
      cardNumber,
      pin,
      balance: 5000.00,
      savingsGoal: 0,
      savingsBalance: 1250.00,
    };
    
    setUser(newUser);
    setIsLoggedIn(true);
  };

  const handleExit = () => {
    setIsLoggedIn(false);
    setUser(null);
  };

  if (!isLoggedIn || !user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return <ATMInterface user={user} onExit={handleExit} />;
}

export default App;